package com.hlc.etiquetas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EtiquetasApplicationTests {

	@Test
	void contextLoads() {
	}

}
