package com.hlc.cliente_uno_a_muchos_pedido;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClienteUnoAMuchosPedidoApplicationTests {

	@Test
	void contextLoads() {
	}

}
