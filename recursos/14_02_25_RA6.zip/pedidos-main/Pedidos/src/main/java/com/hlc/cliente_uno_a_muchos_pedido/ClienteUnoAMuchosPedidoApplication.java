package com.hlc.cliente_uno_a_muchos_pedido;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClienteUnoAMuchosPedidoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClienteUnoAMuchosPedidoApplication.class, args);
	}

}
